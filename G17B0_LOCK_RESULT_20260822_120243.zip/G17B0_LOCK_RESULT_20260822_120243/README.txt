本ZIP由G17-B0只读锁定探针生成。original/保存Windows真实原文件；报告不含数据库密码。
探针未修改D:\TrinityCore。将整个ZIP回传，不要手工编辑其中内容。
