@echo off
setlocal
chcp 65001 >nul
set "ROOT=D:\TC-Build\bin\RelWithDebInfo"
set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not exist "%PYTHON%" (
  echo [STOP] 找不到Python 3.12：%PYTHON%
  pause
  exit /b 2
)
"%PYTHON%" "%~dp0install_g23p3a.py" check "%ROOT%"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo G23-P3A Check完成。READY_TO_APPLY时正常停服后运行Apply；不需要SQL或编译。
) else (
  echo G23-P3A Check未通过，请回传窗口全文；不要手工覆盖。
)
pause
exit /b %RC%
